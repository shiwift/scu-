#pragma once

#include <list>
#include <mutex>  // NOLINT
#include <unordered_map>
#include <vector>

#include "common/config.h"

namespace bustub {

struct LRUKNode {
  std::list<size_t> history_;
  bool is_evictable_{false};
};

class LRUKReplacer {
 public:
  explicit LRUKReplacer(size_t num_frames, size_t k);

  auto Evict(frame_id_t *frame_id) -> bool;

  void RecordAccess(frame_id_t frame_id);

  void SetEvictable(frame_id_t frame_id, bool set_evictable);

  void Remove(frame_id_t frame_id);

  auto Size() -> size_t;

 private:
  size_t current_timestamp_{0};
  size_t curr_size_{0};
  size_t replacer_size_;
  size_t k_;
  std::mutex latch_;
  std::unordered_map<frame_id_t, LRUKNode> node_store_;
};

}  // namespace bustub
