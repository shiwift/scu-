#pragma once

#include <list>
#include <memory>
#include <mutex>
#include <unordered_map>
#include <vector>

#include "buffer/buffer_pool_manager.h"
#include "buffer/lru_k_replacer.h"
#include "container/hash/extendible_hash_table.h"
#include "storage/disk/disk_manager.h"
#include "storage/page/page.h"

namespace bustub {

class BufferPoolManagerInstance : public BufferPoolManager {
 public:
  BufferPoolManagerInstance(size_t pool_size, DiskManager *disk_manager, size_t k_dist,
                            LogManager *log_manager = nullptr)
      : pool_size_(pool_size), disk_manager_(disk_manager), log_manager_(log_manager),
        replacer_(new LRUKReplacer(pool_size, k_dist)) {
    page_table_ = new ExtendibleHashTable<page_id_t, frame_id_t>(pool_size);
    pages_ = new Page[pool_size];
    for (size_t i = 0; i < pool_size; i++) {
      free_list_.push_back(i);
    }
  }

  ~BufferPoolManagerInstance() override {
    delete page_table_;
    delete[] pages_;
  }

  auto GetPoolSize() -> size_t override { return pool_size_; }

  auto NewPgImp(page_id_t *page_id) -> Page * override;
  auto FetchPgImp(page_id_t page_id) -> Page * override;
  auto UnpinPgImp(page_id_t page_id, bool is_dirty) -> bool override;
  auto FlushPgImp(page_id_t page_id) -> bool override;
  auto DeletePgImp(page_id_t page_id) -> bool override;
  void FlushAllPgsImp() override;

 private:
  size_t pool_size_;
  DiskManager *disk_manager_;
  LogManager *log_manager_;
  page_id_t next_page_id_{0};

  std::mutex latch_;
  Page *pages_;
  std::unique_ptr<LRUKReplacer> replacer_;
  ExtendibleHashTable<page_id_t, frame_id_t> *page_table_;
  std::list<frame_id_t> free_list_;
};

}  // namespace bustub
