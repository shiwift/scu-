#include "buffer/lru_k_replacer.h"

#include <algorithm>
#include <limits>

namespace bustub {

LRUKReplacer::LRUKReplacer(size_t num_frames, size_t k) : replacer_size_(num_frames), k_(k) {}

auto LRUKReplacer::Evict(frame_id_t *frame_id) -> bool {
  std::scoped_lock<std::mutex> lock(latch_);
  frame_id_t victim = -1;
  size_t max_dist = 0;
  size_t earliest_time = std::numeric_limits<size_t>::max();
  bool found = false;

  for (auto &pair : node_store_) {
    frame_id_t fid = pair.first;
    LRUKNode &node = pair.second;
    
    if (!node.is_evictable_) {
      continue;
    }

    size_t dist = (node.history_.size() < k_) ? std::numeric_limits<size_t>::max() : (current_timestamp_ - node.history_.front());
    size_t time = node.history_.front();

    if (!found) {
      victim = fid;
      max_dist = dist;
      earliest_time = time;
      found = true;
    } else {
      if (max_dist == std::numeric_limits<size_t>::max()) {
        if (dist == std::numeric_limits<size_t>::max()) {
          if (time < earliest_time) {
            victim = fid;
            max_dist = dist;
            earliest_time = time;
          }
        }
      } else if (dist == std::numeric_limits<size_t>::max()) {
        victim = fid;
        max_dist = dist;
        earliest_time = time;
      } else {
        if (dist > max_dist) {
          victim = fid;
          max_dist = dist;
          earliest_time = time;
        } else if (dist == max_dist && time < earliest_time) {
          victim = fid;
          max_dist = dist;
          earliest_time = time;
        }
      }
    }
  }

  if (found) {
    *frame_id = victim;
    curr_size_--;
    node_store_.erase(victim);
    return true;
  }
  return false;
}

void LRUKReplacer::RecordAccess(frame_id_t frame_id) {
  std::scoped_lock<std::mutex> lock(latch_);
  auto it = node_store_.find(frame_id);
  if (it == node_store_.end()) {
    LRUKNode new_node;
    new_node.history_.push_back(current_timestamp_);
    node_store_[frame_id] = new_node;
  } else {
    if (it->second.history_.size() == k_) {
      it->second.history_.pop_front();
    }
    it->second.history_.push_back(current_timestamp_);
  }
  current_timestamp_++;
}

void LRUKReplacer::SetEvictable(frame_id_t frame_id, bool set_evictable) {
  std::scoped_lock<std::mutex> lock(latch_);
  auto it = node_store_.find(frame_id);
  if (it == node_store_.end()) {
    return;
  }
  if (it->second.is_evictable_ == set_evictable) {
    return;
  }
  
  it->second.is_evictable_ = set_evictable;
  if (set_evictable) {
    curr_size_++;
  } else {
    curr_size_--;
  }
}

void LRUKReplacer::Remove(frame_id_t frame_id) {
  std::scoped_lock<std::mutex> lock(latch_);
  auto it = node_store_.find(frame_id);
  if (it == node_store_.end()) {
    return;
  }
  if (it->second.is_evictable_) {
    curr_size_--;
  }
  node_store_.erase(it);
}

auto LRUKReplacer::Size() -> size_t {
  std::scoped_lock<std::mutex> lock(latch_);
  return curr_size_;
}

}  // namespace bustub
